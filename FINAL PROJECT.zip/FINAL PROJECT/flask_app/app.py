import csv
from flask import Flask, render_template, request, redirect
from pymongo import MongoClient


app = Flask(__name__)

# MongoDB Atlas connection
client = MongoClient(
    "mongodb+srv://petoniakinta:zLTS95XSCN3CsZ5T@clusterfp.ulyurov.mongodb.net/")
db = client["user_data"]
collection = db["submissions"]


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        data = {
            "age": int(request.form["age"]),
            "gender": request.form["gender"],
            "income": float(request.form["income"]),
            "expenses": {}
        }

        categories = ["utilities", "entertainment",
                      "school_fees", "shopping", "healthcare"]
        for category in categories:
            if category in request.form:
                amount = request.form.get(f"{category}_amount", "0")
                data["expenses"][category] = float(amount)

        collection.insert_one(data)
        return redirect("/success")

    return render_template("form.html")


@app.route("/success")
def success():
    return "<h2>Submission successful!</h2>"


def __init__(self):
    uri = "mongodb+srv://petoniakinta:zLTS95XSCN3CsZ5T@clusterfp.ulyurov.mongodb.net/"
    self.client = MongoClient(uri)
    self.db = self.client["user_data"]
    self.collection = self.db["submissions"]


def export_to_csv(self, filename="user_data.csv"):
    users = list(self.collection.find())
    headers = ["age", "gender", "income", "utilities",
               "entertainment", "school_fees", "shopping", "healthcare"]

    with open(filename, mode="w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=headers)
        writer.writeheader()

        # Loop through each user document
        for user in users:
            row = {
                "age": user.get("age", ""),
                "gender": user.get("gender", ""),
                "income": user.get("income", "")
            }
        # Loop through expense categories
        for category in headers[3:]:
            row[category] = user.get("expenses", {}).get(category, 0)
            writer.writerow(row)

    print(f"Data saved to {filename}")


if __name__ == "__main__":
    app.run(debug=True)
