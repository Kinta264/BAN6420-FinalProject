
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("user_data.submissions.csv")
df.drop(columns=["_id"], inplace=True)
df.columns = [
    "age", "gender", "income", "utilities", "entertainment",
    "school_fees", "shopping", "healthcare"
]

expense_cols = ["utilities", "entertainment", "school_fees", "shopping", "healthcare"]
df[expense_cols] = df[expense_cols].fillna(0).astype(float)

avg_spending = df.groupby("gender")[expense_cols].mean()

avg_spending.T.plot(kind="bar", figsize=(10, 6))
plt.title("Average Spending by Gender Across Categories")
plt.xlabel("Expense Category")
plt.ylabel("Average Amount Spent")
plt.xticks(rotation=45)
plt.legend(title="Gender")
plt.tight_layout()
plt.savefig("spending_by_gender.png")
plt.show()
