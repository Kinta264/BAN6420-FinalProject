
from pptx import Presentation
from pptx.util import Inches

# Create a new PowerPoint presentation
prs = Presentation()
layout = prs.slide_layouts[5]  # Title Only layout

# Add slide for Income Distribution by Age
slide1 = prs.slides.add_slide(layout)
title1 = slide1.shapes.title
if title1:
    title1.text = "Income Distribution by Age"
slide1.shapes.add_picture("income_by_age.png", Inches(1), Inches(1.5), width=Inches(8))

# Add slide for Spending by Gender
slide2 = prs.slides.add_slide(layout)
title2 = slide2.shapes.title
if title2:
    title2.text = "Spending by Gender Across Categories"
slide2.shapes.add_picture("spending_by_gender.png", Inches(1), Inches(1.5), width=Inches(8))

# Save the presentation
prs.save("user_data_visualizations.pptx")
